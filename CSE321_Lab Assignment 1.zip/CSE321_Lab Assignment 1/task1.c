#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int fibLimit;
int *fibArray = NULL;
int searchCount;
int *searchList;

void* generateFib(void *arg) {
    fibArray = malloc((fibLimit + 1) * sizeof(int));
    if (!fibArray) pthread_exit(NULL);

    if (fibLimit >= 0) fibArray[0] = 0;
    if (fibLimit >= 1) fibArray[1] = 1;

    for (int i = 2; i <= fibLimit; i++)
        fibArray[i] = fibArray[i - 1] + fibArray[i - 2];

    pthread_exit(NULL);
}

void* searchFib(void *arg) {
    for (int i = 0; i < searchCount; i++) {
        int idx = searchList[i];
        if (idx >= 0 && idx <= fibLimit)
            printf("result of search #%d = %d\n", i + 1, fibArray[idx]);
        else
            printf("result of search #%d = -1\n", i + 1);
    }
    pthread_exit(NULL);
}

int main() {
    pthread_t t1, t2;

    printf("Enter the term of fibonacci sequence:\n");
    scanf("%d", &fibLimit);

    printf("How many numbers you are willing to search?:\n");
    scanf("%d", &searchCount);

    searchList = malloc(searchCount * sizeof(int));

    for (int i = 0; i < searchCount; i++) {
        printf("Enter search %d:\n", i + 1);
        scanf("%d", &searchList[i]);
    }

    pthread_create(&t1, NULL, generateFib, NULL);
    pthread_join(t1, NULL);

    for (int i = 0; i <= fibLimit; i++)
        printf("a[%d] = %d\n", i, fibArray[i]);

    pthread_create(&t2, NULL, searchFib, NULL);
    pthread_join(t2, NULL);

    free(fibArray);
    free(searchList);

    return 0;
}
