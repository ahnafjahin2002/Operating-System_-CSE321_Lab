#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

typedef enum {BREAD, CHEESE, LETTUCE} item;

pthread_mutex_t tableLock;

sem_t semA;
sem_t semB;
sem_t semC;
sem_t semSupplier;

item tableX, tableY;
int rounds;

const char* name(item x) {
    if (x == BREAD) return "Bread";
    if (x == CHEESE) return "Cheese";
    return "Lettuce";
}

void* Supplier(void *arg) {
    // CORRECTION: Capture the initial number of rounds locally.
    // We cannot rely on the global 'rounds' variable in the loop because
    // the Maker threads decrement it while this thread is running.
    int limit = rounds;

    // Fixed sequence to match the sample output
    item sequence[100][2]; // array large enough for general rounds
    
    // Use the local 'limit' for setup
    for (int i = 0; i < limit; i++) {
        if (i % 3 == 0) { sequence[i][0] = BREAD; sequence[i][1] = CHEESE; }
        else if (i % 3 == 1) { sequence[i][0] = CHEESE; sequence[i][1] = LETTUCE; }
        else { sequence[i][0] = BREAD; sequence[i][1] = LETTUCE; }
    }

    // Use the local 'limit' for execution loop
    for (int i = 0; i < limit; i++) {
        sem_wait(&semSupplier);
        pthread_mutex_lock(&tableLock);

        tableX = sequence[i][0];
        tableY = sequence[i][1];

        printf("Supplier places: %s and %s\n", name(tableX), name(tableY));

        if ((tableX == BREAD && tableY == CHEESE) || (tableX == CHEESE && tableY == BREAD))
            sem_post(&semC);
        else if ((tableX == CHEESE && tableY == LETTUCE) || (tableX == LETTUCE && tableY == CHEESE))
            sem_post(&semA);
        else
            sem_post(&semB);

        pthread_mutex_unlock(&tableLock);
    }
    return NULL;
}

void* makerA(void *arg) {
    while (1) {
        sem_wait(&semA);
        pthread_mutex_lock(&tableLock);

        if (rounds <= 0) { pthread_mutex_unlock(&tableLock); break; }

        printf("Maker A picks up %s and %s\n", name(tableX), name(tableY));
        printf("Maker A is making the sandwich...\n");
        printf("Maker A finished making the sandwich and eats it\n");
        printf("Maker A signals Supplier\n");

        rounds--;
        sem_post(&semSupplier);

        pthread_mutex_unlock(&tableLock);
    }
    return NULL;
}

void* makerB(void *arg) {
    while (1) {
        sem_wait(&semB);
        pthread_mutex_lock(&tableLock);

        if (rounds <= 0) { pthread_mutex_unlock(&tableLock); break; }

        printf("Maker B picks up %s and %s\n", name(tableX), name(tableY));
        printf("Maker B is making the sandwich...\n");
        printf("Maker B finished making the sandwich and eats it\n");
        printf("Maker B signals Supplier\n");

        rounds--;
        sem_post(&semSupplier);

        pthread_mutex_unlock(&tableLock);
    }
    return NULL;
}

void* makerC(void *arg) {
    while (1) {
        sem_wait(&semC);
        pthread_mutex_lock(&tableLock);

        if (rounds <= 0) { pthread_mutex_unlock(&tableLock); break; }

        printf("Maker C picks up %s and %s\n", name(tableX), name(tableY));
        printf("Maker C is making the sandwich...\n");
        printf("Maker C finished making the sandwich and eats it\n");
        printf("Maker C signals Supplier\n");

        rounds--;
        sem_post(&semSupplier);

        pthread_mutex_unlock(&tableLock);
    }
    return NULL;
}

int main() {
    pthread_t ts, ta, tb, tc;

    printf("Enter how many times supplier places ingredients:\n");
    scanf("%d", &rounds);

    pthread_mutex_init(&tableLock, NULL);

    sem_init(&semA, 0, 0);
    sem_init(&semB, 0, 0);
    sem_init(&semC, 0, 0);
    sem_init(&semSupplier, 0, 1);

    pthread_create(&ts, NULL, Supplier, NULL);
    pthread_create(&ta, NULL, makerA, NULL);
    pthread_create(&tb, NULL, makerB, NULL);
    pthread_create(&tc, NULL, makerC, NULL);

    pthread_join(ts, NULL);

    // Post semaphores to ensure makers wake up and check rounds <= 0 to exit cleanly
    sem_post(&semA);
    sem_post(&semB);
    sem_post(&semC);

    pthread_join(ta, NULL);
    pthread_join(tb, NULL);
    pthread_join(tc, NULL);

    return 0;
}
